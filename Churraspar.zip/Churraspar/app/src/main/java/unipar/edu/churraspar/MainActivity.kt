package unipar.edu.churraspar

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputHomens: EditText
    private lateinit var inputMulheres: EditText
    private lateinit var inputCriancas: EditText
    private lateinit var tvResultado: TextView
    private lateinit var btCalcular: Button
    private lateinit var buttonLimpar: Button
    private lateinit var inputCarne: EditText
    private lateinit var inputAperitivos: EditText
    private lateinit var inputTotalComida: EditText
    private lateinit var inputCerveja: EditText
    private lateinit var inputAgua: EditText
    private lateinit var inputRefrigerante: EditText
    private lateinit var inputTextTotalBebidas: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialização dos campos
        inputHomens = findViewById(R.id.inputTextHomens)
        inputMulheres = findViewById(R.id.inputTextMulheres)
        inputCriancas = findViewById(R.id.inputTextCriancas)
        tvResultado = findViewById(R.id.tvResultado)
        btCalcular = findViewById(R.id.btCalcular)
        buttonLimpar = findViewById(R.id.ButtonLimpar)
        inputCarne = findViewById(R.id.InputTextCarne)
        inputAperitivos = findViewById(R.id.InputTextAperitivos)
        inputTotalComida = findViewById(R.id.inputTextTotalComida)
        inputCerveja = findViewById(R.id.inputTextCerveja)
        inputAgua = findViewById(R.id.inputTextAgua)
        inputRefrigerante = findViewById(R.id.inputTextRefrigerante)
        inputTextTotalBebidas = findViewById(R.id.inputTextTotalBebidas)

        // Configuração dos listeners
        btCalcular.setOnClickListener { calcular() }
        buttonLimpar.setOnClickListener { limpar() }
    }

    private fun calcular() {
        // Coletando e convertendo entradas
        val homens = inputHomens.text.toString().toIntOrNull() ?: 0
        val mulheres = inputMulheres.text.toString().toIntOrNull() ?: 0
        val criancas = inputCriancas.text.toString().toIntOrNull() ?: 0

        // Cálculo das quantidades
        val totalCarne = (homens * 400 + mulheres * 300 + criancas * 200) * 1.1
        val totalAperitivos = (homens * 150 + mulheres * 100 + criancas * 50) * 1.1
        val totalBebidaAlcoolica = (homens * 4 + mulheres * 2) * 1.1
        val totalAgua = (mulheres + criancas) * 2 * 1.1
        val totalRefrigerante = (mulheres + criancas) * 1.5 * 1.1
        val totalBebidas: Double = totalBebidaAlcoolica + totalAgua + totalRefrigerante

        // Atualizando os campos com os resultados
        inputCarne.setText("${totalCarne.toInt()}g (Com Extra)")
        inputAperitivos.setText("${totalAperitivos.toInt()}g (Com Extra) ")
        inputTotalComida.setText("${(totalCarne + totalAperitivos).toInt()}g")
        inputCerveja.setText("${totalBebidaAlcoolica.toInt()}L (Com Extra)")
        inputAgua.setText("${totalAgua.toInt()}L (Com Extra) ")
        inputRefrigerante.setText("${totalRefrigerante.toInt()}L (Com Extra)")
        inputTextTotalBebidas.setText("${totalBebidas.toDouble()}L Total")

        // Atualizando o resultado da contagem de participantes
        val totalPessoas = (homens + mulheres + criancas)
        tvResultado.text = "Realizamos o cálculo para $totalPessoas participantes"
    }

    private fun limpar() {
        // Limpa todos os campos de entrada
        inputHomens.text.clear()
        inputMulheres.text.clear()
        inputCriancas.text.clear()
        inputCarne.text.clear()
        inputAperitivos.text.clear()
        inputTotalComida.text.clear()
        inputCerveja.text.clear()
        inputAgua.text.clear()
        inputRefrigerante.text.clear()
        inputTextTotalBebidas.text.clear()
        tvResultado.text = ""
    }
}
